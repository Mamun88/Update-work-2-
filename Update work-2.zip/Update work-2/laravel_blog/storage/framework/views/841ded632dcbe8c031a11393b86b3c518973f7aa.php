<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        
    <div class="col-md-6">
            <div class="card">
                <div class="card-header" style="background: #282923; color: #fff; text-align: center;">Product Category Insert</div>

                <div class="card-body">
                 

                    <?php if(session('status')): ?>
                    <div class="alert alert-success">
                    	 <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    



                    <form action="<?php echo e(route('category.store')); ?>" method="post" enctype="multipart/form-data">
					  <?php echo csrf_field(); ?>
					  <div class="form-group">
					    <label for="category_name">Category Name</label>
					    <input type="text" class="form-control" name="category_name" id="category_name" placeholder="Enter Product Category Name">
					  </div>

					  					  	  
					  
					  <button type="submit" class="btn btn-primary">Submit</button>
					</form>
                   
                </div>
            </div>
        </div>     


       
    
    </div>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp1\htdocs\laravel_blog\resources\views/backend/category/category_form.blade.php ENDPATH**/ ?>